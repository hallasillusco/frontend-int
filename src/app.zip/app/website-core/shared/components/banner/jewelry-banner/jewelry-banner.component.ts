import { Component } from '@angular/core';

@Component({
  selector: 'app-jewelry-banner',
  templateUrl: './jewelry-banner.component.html',
  styleUrls: ['./jewelry-banner.component.scss']
})
export class JewelryBannerComponent {

}
