import { HasRolesDirective } from './has-roles.directive';

describe('HasRolesDirective', () => {
  it('should create an instance', () => {
    const directive = new HasRolesDirective();
    expect(directive).toBeTruthy();
  });
});
