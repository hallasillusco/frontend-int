import { Subject } from 'rxjs';

export interface SharedComponentInterface {
  subjectShared: Subject<any>;
}
