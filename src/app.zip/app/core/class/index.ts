// start:ng42.barrel
export * from './baseAPI.class';
// end:ng42.barrel
