/**
 * CONTANTES DE CRUDS
 */
export const BASEAPI_PATH = {
  ALL: `/all`,
  ENABLED: `habilitar`,
  ENABLEDALL: `habilitados`
};
