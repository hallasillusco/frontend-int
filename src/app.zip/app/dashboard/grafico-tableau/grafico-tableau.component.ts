import { Component } from '@angular/core';

@Component({
  selector: 'app-grafico-tableau',
  standalone: true,
  imports: [],
  templateUrl: './grafico-tableau.component.html',
  styleUrl: './grafico-tableau.component.scss'
})
export class GraficoTableauComponent {

}
